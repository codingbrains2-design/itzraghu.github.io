<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Todo App</title>
	<meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
	{!! Html::style("http://fonts.googleapis.com/css?family=Lato") !!}
	{!! Html::style("public/css/http://fonts.googleapis.com/css?family=Open+Sans:400,600") !!}
	{!! Html::style("public/css/bootstrap.min.css") !!}
	{!! Html::style("public/css/font-awesome.min.css") !!}
	{!! Html::style("public/css/todo.css") !!}

</head>
<body>


