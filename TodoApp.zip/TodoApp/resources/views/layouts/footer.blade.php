<footer>
	Copyright &copy;<?php echo date('Y')?> {!! Html::link('http://itzraghu.github.io','Raghvendra Pratap Singh') !!}
</footer>

{!! Html::script("public/js/jquery.min.js") !!}
{!! Html::script("public/js/bootstrap.min.js") !!}


</body>
</html>